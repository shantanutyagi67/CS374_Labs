function [y]=f(x)
    
    y=exp(-x) - 1 + x/5;
end